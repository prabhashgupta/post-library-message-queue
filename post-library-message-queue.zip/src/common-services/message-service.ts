import { IEventMessage } from "../interfaces/event-message.interface";
import { RabbitMQService } from "../rabbitmq";

export class MessageService {
    public static async send<T>(publishTo: string, message: IEventMessage<T>) {
        try {
            // 
            await RabbitMQService.connection.publish(publishTo, message);
        } catch (error) {
            throw error;
        }
    }

}