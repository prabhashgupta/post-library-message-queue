import * as express from "express"
import * as bodyParser from "body-parser"
import { AppDataSource } from "./data-source"
import { join } from "path"

AppDataSource.initialize().then(async () => {

    // create express app
    const app = express();
    const cors = require('cors'); // enables cross origin requests in headers
    app.use(cors());
    app.use(bodyParser.json());

    const PORT = process.env.PORT || 3000;

    // for auto mounting.
    const autoRoutes = require('express-auto-routes')(app);
    autoRoutes(join(__dirname, './controllers')); // 

    app.listen(PORT, () => {
        console.log(`Node server listening on http://localhost:${PORT}`);
    });

    app.get('/ping', (req, res) => {
        res.send('pong');
    });
}).catch(error => console.log(error))
