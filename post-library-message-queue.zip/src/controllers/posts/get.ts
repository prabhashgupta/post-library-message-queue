import { Request, Response } from "express";
import { PostBLL } from "../../business-logic-layer/post.bll";

exports.get = async (req: Request, res: Response) => {
    const response: { statusCode?: number, data?: any, errorMessage?: string } = {}
    try {
        const skip = req.query.skip ?? 0;
        const take = req.query.take ?? 25;
        const data = await new PostBLL().get(skip, take);
        if (data && data.length) {
            response.statusCode = 200;
            response.data = data;
        } else {
            response.statusCode = 404;
            response.errorMessage = "No records found";
        }
    } catch (error) {
        response.statusCode = 500;
        response.errorMessage = error.message;
    }
    res.status(response.statusCode).send(response);
}