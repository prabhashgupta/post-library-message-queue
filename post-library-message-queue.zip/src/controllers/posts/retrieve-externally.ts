import { Request, Response } from "express";
import { PostBLL } from "../../business-logic-layer/post.bll";

exports.post = async (req: Request, res: Response) => {
    const response: { statusCode: number, data: any, errorMessage?: string } = {
        statusCode: 200,
        data: "Saved successfully"
    }
    try {
        await new PostBLL().retrieveExternally();
        res.status(200);
    } catch (error) {
        res.status(500);
        response.statusCode = 500;
        response.errorMessage = error.message;
        response.data = error;
    }
    res.send(response);
}