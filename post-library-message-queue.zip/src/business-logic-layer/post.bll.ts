import { Post } from "../entities/Post"
import { AppDataSource } from "../data-source"
import axios from "axios";
import { MessageService } from "../common-services/message-service";
import { IEventMessage } from "../interfaces/event-message.interface";

export class PostBLL {

    private postRepository = AppDataSource.getRepository(Post);

    public async get(skip: number, take: number) {
        try {
            const posts = await this.postRepository.find({ skip, take });
            return posts;
        } catch (error) {
            throw new Error('method: get class: ' + this.constructor.name + ' error: ' + error.message);
        }
        
    }

    public async retrieveExternally() {
        try {
            let posts: Post[] = [];
            while (posts.length <= 25) {
                const res = await axios.get("https://jsonplaceholder.typicode.com/posts");
                if (res && res.data) {
                    const data = this.postRepository.create(res.data as Post[]);
                    await this.publish(data);
                    posts = posts.concat(data);
                }
            }
        } catch (error) {
            throw new Error('method: retrieveExternally class: ' + this.constructor.name + ' error: ' + error.message);
        }

    }

    public async publish(messages: Post[]) {
        try {
            for (let i = 0; i < messages.length; i++) {
                const message: IEventMessage<Post> = {
                    action: 'savePost',
                    source: 'external',
                    destination: 'sample-db',
                    payload: messages[i]
                }
                await MessageService.send('post-publisher', message);
            }
        } catch (error) {
            throw new Error('method: publish class: ' + this.constructor.name + ' error: ' + error.message);
        }
    }

    public async save(postDetails: Post) {
        try {
            const post = this.postRepository.create(postDetails);
            await this.postRepository.save(post);
        } catch (error) {
            throw new Error('method: publish class: ' + this.constructor.name + ' error: ' + error.message);
        }

    }

}