import { PostBLL } from "../business-logic-layer/post.bll";
import { Post } from "../entities/Post";
import { IEventMessage } from "../interfaces/event-message.interface";
import { RabbitMQService } from "../rabbitmq";

RabbitMQService.connection
    .subscribe('post-consumer').then(subscription => {
        subscription.on('message', async (message, payload: IEventMessage<Post>, ackOrNack) => {
            try {
                await new PostBLL().save(payload.payload);
                ackOrNack();
            } catch (error) {
                ackOrNack(error);
            }
            
        })
    })
