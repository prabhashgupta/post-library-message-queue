// RabbitMQ configuration and setup will be done here

export class RabbitMQService {
    public static connection: any
}