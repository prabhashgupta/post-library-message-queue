export interface IEventMessage<T> {
    uid?: string;
    payload: T;
    action: string;

    source: string;

    destination: string;
}